set -e

cd /output && ./MyStrategy "$@"